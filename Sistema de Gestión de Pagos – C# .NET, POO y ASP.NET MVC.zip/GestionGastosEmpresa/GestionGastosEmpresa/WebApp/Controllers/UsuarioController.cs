﻿using Dominio.Entidades;
using Dominio.Sistema;
using Microsoft.AspNetCore.Mvc;

namespace WebApp.Controllers
{
    public class UsuarioController : Controller
    {
        Sistema s = Sistema.GetInstancia();
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Perfil()
        {

            int? lid = HttpContext.Session.GetInt32("LogueadoId");
            if (lid == null)
            {
                // Si no hay usuario logueado, redirige al login
                return RedirectToAction("Login", "Auth");
            }

            Usuario uLogueado = s.GetUsuarioPorId(lid);
            decimal gastadoEsteMes = s.GetGastadoEsteMes(lid);
            ViewBag.Usuario = uLogueado;
            ViewBag.Gastado = gastadoEsteMes;
            ViewBag.MiembrosEquipo = s.GetUsuariosPorEquipo(uLogueado.Equipo.Nombre);
            ViewBag.MiembrosEquipo.Sort();

            return View();
        }
    }
}
