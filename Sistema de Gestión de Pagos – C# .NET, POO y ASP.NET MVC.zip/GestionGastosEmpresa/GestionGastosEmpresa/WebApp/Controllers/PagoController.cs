﻿using Dominio.Sistema;
using Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;
using Dominio;
using System.Globalization;

namespace WebApp.Controllers
{
    public class PagoController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        public IActionResult ListarMisPagos()
        {
            if (HttpContext.Session.GetInt32("LogueadoId") is null)
            {
                return RedirectToAction("Login", "Auth");
            }
            else
            {
                string email = HttpContext.Session.GetString("LogueadoEmail");
                List<Pago> pagosDelUsuario = s.GetPagosPorUsuario(email);
                List<Pago> pagosDelMesDelUsuario = s.GetPagosMesActual(pagosDelUsuario);
                return View(pagosDelMesDelUsuario);
            }
        }



        public IActionResult ListarPagosDeMiEquipo()
        {
            if (HttpContext.Session.GetInt32("LogueadoId") is null)
            {
                return RedirectToAction("Login", "Auth");
            }
            else
            {
                int? lid = HttpContext.Session.GetInt32("LogueadoId");

                Usuario logueado = s.GetUsuarioPorId(lid);

                Equipo equipoDelLogueado = logueado.Equipo;

                List<Pago> pagosDeMiEquipo = s.GetPagosPorEquipo(equipoDelLogueado);
                List<Pago> pagoDeMiEquipoDelMes = s.GetPagosMesActual(pagosDeMiEquipo);

                return View(pagoDeMiEquipoDelMes);
            }

        }

        [HttpPost]
        public IActionResult ListarPagosDeMiEquipo(string anio, string mes)
        {
            try
            {
                int anioBuscado = int.Parse(anio);
                int mesBuscado = int.Parse(mes);

                int? lid = HttpContext.Session.GetInt32("LogueadoId");
                Usuario logueado = s.GetUsuarioPorId(lid);
                Equipo equipoDelLogueado = logueado.Equipo;

                List<Pago> pagosPorMes = s.GetPagosPorMes(anioBuscado, mesBuscado);
                List<Pago> pagosPorMesDeMiEquipo = new List<Pago>();

                foreach (Pago p in pagosPorMes)
                {
                    if (p.Usuario.Equipo == equipoDelLogueado)
                    {
                        pagosPorMesDeMiEquipo.Add(p);
                    }
                }
                pagosPorMesDeMiEquipo.Sort();
                return View(pagosPorMesDeMiEquipo);
            }
            catch (Exception e)
            {
                ViewBag.msg = "Debe escribir un año y un mes válidos.";
                return View();
            }
        }

        [HttpGet]
        public IActionResult CargarPagoUnico()
        {
            if (HttpContext.Session.GetInt32("LogueadoId") is null)
            {
                return RedirectToAction("Login", "Auth");
            }
            else
            {
                List<TipoGasto> listaTipoGastos = s.GetTipoGastos();
                ViewBag.lista = listaTipoGastos;
                return View();
            }
        }

        [HttpPost]
        public IActionResult CargarPagoUnico(PagoUnico nuevo, int MetodoPago, int TipoGasto)
        {

            try
            {
                nuevo.Usuario = s.GetUsuarioPorMail(HttpContext.Session.GetString("LogueadoEmail"));
                nuevo.TipoGasto = s.GetTipoGastoPorId(TipoGasto);

                if (MetodoPago == 1)
                {
                    nuevo.MetodoPago = Dominio.MetodoPago.DEBITO;
                }
                if (MetodoPago == 2)
                {
                    nuevo.MetodoPago = Dominio.MetodoPago.EFECTIVO;
                }
                else
                {
                    nuevo.MetodoPago = Dominio.MetodoPago.CREDITO;
                }

                s.AltaPagoUnico(nuevo);
                ViewBag.msg = "Pago cargado correctamente";
            }
            catch (Exception e)
            {
                ViewBag.msg = e.Message;
            }

            List<TipoGasto> listaTipoGastos = s.GetTipoGastos();
            ViewBag.lista = listaTipoGastos;
            return View();

        }

        [HttpGet]
        public IActionResult CargarPagoRecurrente()
        {
            if (HttpContext.Session.GetInt32("LogueadoId") is null)
            {
                return RedirectToAction("Login", "Auth");
            }
            else
            {
                List<TipoGasto> listaTipoGastos = s.GetTipoGastos();
                ViewBag.lista = listaTipoGastos;
                return View();
            }

        }

        [HttpPost]
        public IActionResult CargarPagoRecurrente(PagoRecurrente nuevo, int MetodoPago, int TipoGasto)
        {
            try
            {
                nuevo.Usuario = s.GetUsuarioPorMail(HttpContext.Session.GetString("LogueadoEmail"));
                nuevo.TipoGasto = s.GetTipoGastoPorId(TipoGasto);

                if (MetodoPago == 1)
                {
                    nuevo.MetodoPago = Dominio.MetodoPago.DEBITO;
                }
                if (MetodoPago == 2)
                {
                    nuevo.MetodoPago = Dominio.MetodoPago.EFECTIVO;
                }
                else
                {
                    nuevo.MetodoPago = Dominio.MetodoPago.CREDITO;
                }
                s.AltaPagoRecurrente(nuevo);
                ViewBag.msg = "Pago cargado correctamente";
            }
            catch (Exception e)
            {
                ViewBag.msg = e.Message;
            }

            List<TipoGasto> listaTipoGastos = s.GetTipoGastos();
            ViewBag.lista = listaTipoGastos;
            return View();
        }


    }
}
