﻿using Dominio.Sistema;
using Dominio.Entidades;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApp.Controllers
{
    public class TipoGastoController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        public IActionResult ListarTipoGasto()
        {
            if (HttpContext.Session.GetInt32("LogueadoId") == null)
            {
                return RedirectToAction("Login", "Auth");
            }
            else
            {
                List<TipoGasto> todoslostiposdegastos = s.GetTipoGastos();

                return View(todoslostiposdegastos);
            }
        }

        [HttpGet]
        public IActionResult CargarTipoGasto()
        {
            if (HttpContext.Session.GetInt32("LogueadoId") == null)
            {
                return RedirectToAction("Login", "Auth");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public IActionResult CargarTipoGasto(TipoGasto nuevo)
        {
            try
            {
                s.AltaTipoGasto(nuevo);
                ViewBag.msg = "Nuevo Tipo de Gasto cargado correctamente";
            }
            catch (Exception e)
            {
                ViewBag.msg = e.Message;
            }
            return View();

        }


        public IActionResult Delete(int id)
        {
            if (HttpContext.Session.GetInt32("LogueadoId") == null)
            {
                return RedirectToAction("Login", "Auth");
            }
            else if (HttpContext.Session.GetString("LogueadoRol") == "Gerente")
            {
                TipoGasto aEliminar = s.GetTipoGastoPorId(id);
                if (aEliminar == null)
                {
                    return RedirectToAction("ListarTipoGasto", "TipoGasto");
                }
                if (aEliminar.Eliminado == true)
                {
                    ViewBag.msg = "El tipo de gasto ya se encuentra eliminado.";
                }
                foreach (Pago p in s.GetPagos())
                {
                    if (p.TipoGasto.Id == aEliminar.Id)
                    {
                        ViewBag.msg = "No se puede eliminar este tipo de gasto porque está siendo utilizado en uno o más pagos.";
                    }
                }
                return View(aEliminar);
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public IActionResult Delete(int id, IFormCollection form)
        {
            try
            {
                s.EliminarTipoGasto(id);
                return RedirectToAction("ListarTipoGasto");
            }
            catch (Exception e)
            {
                TipoGasto aEliminar = s.GetTipoGastoPorId(id);
                ViewBag.msg = e.Message;
                return View(aEliminar);
            }

        }

    }
}
