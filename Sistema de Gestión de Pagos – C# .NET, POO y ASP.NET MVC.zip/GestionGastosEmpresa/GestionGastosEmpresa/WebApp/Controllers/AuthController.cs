﻿using Dominio;
using Dominio.Entidades;
using Dominio.Sistema;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class AuthController : Controller

    {

        Sistema s = Sistema.GetInstancia();
        public IActionResult Login()
        {
            if (HttpContext.Session.GetInt32("LogueadoId") != null)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }


        [HttpPost]
        public IActionResult Login(LoginModel lm)
        {
            Usuario buscado = s.ExisteUsuario(lm.Email, lm.Pass);

            if (buscado != null)
            {
                // Variables de sesión
                HttpContext.Session.SetInt32("LogueadoId", buscado.Id);
                HttpContext.Session.SetString("LogueadoNombre", buscado.Nombre + " " + buscado.Apellido);
                HttpContext.Session.SetString("LogueadoRol", buscado.Rol);
                HttpContext.Session.SetString("LogueadoEmail", buscado.Email);

                return RedirectToAction("Index", "Home");

            }
            else
            {
                ViewBag.msg = "Credenciales no válidas";
                return View();

            }



        }
        public IActionResult LogOut()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Index", "Home");

        }
    }
}
