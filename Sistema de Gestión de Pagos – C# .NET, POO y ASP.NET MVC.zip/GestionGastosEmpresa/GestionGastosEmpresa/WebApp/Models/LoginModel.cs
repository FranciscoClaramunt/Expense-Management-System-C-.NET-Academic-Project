﻿namespace WebApp.Models
{
    public class LoginModel
    {
        public string Email { get; set; }
        public string Pass { get; set; }
    }
}
