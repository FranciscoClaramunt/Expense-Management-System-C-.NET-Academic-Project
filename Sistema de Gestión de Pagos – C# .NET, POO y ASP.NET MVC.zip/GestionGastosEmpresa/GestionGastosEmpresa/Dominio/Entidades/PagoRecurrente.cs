﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidades
{
    public class PagoRecurrente : Pago
    {
        public DateTime? FechaHasta { get; set; }

        //Constructor
        public PagoRecurrente() { }

        public PagoRecurrente(MetodoPago metodoPago, decimal monto, TipoGasto tipoGasto, Usuario usuario, string descripcion, DateTime fecha, DateTime? fechaHasta)
            : base(metodoPago, monto, tipoGasto, usuario, descripcion, fecha)
        {
            FechaHasta = fechaHasta;
        }

        // Validaciones
        public void Validar()
        {
            base.Validar();

            if (Fecha > FechaHasta)
            {
                throw new Exception("La fecha de inicio del pago no puede ser mayor a la fecha de finalización.");
            }
        }

        /// <summary>
        /// Método CalcularMontoTotal (override de clase padre Pago)
        /// </summary>
        /// <returns></returns>
        public override decimal CalcularMontoTotal()
        {
            if (FechaHasta == null)
            {
                return Monto * 1.03m;

            }
            else
            {

                int totalMeses = CalcularTotalCuotas();

                
                if (totalMeses >= 10)
                {
                    return (Monto * totalMeses) * 1.1m;

                }
                else if (totalMeses >= 6 && totalMeses <= 9)
                {
                    return (Monto * totalMeses) * 1.05m;

                }
                else
                {
                    return (Monto * totalMeses) * 1.03m;
                }
            }
        }


        public int CalcularTotalCuotas()
        {
            // Si no tiene fecha de fin → no hay cuotas “pendientes fijas”
            if (!FechaHasta.HasValue)
            {
                return 0;
            }
            else 
            {
                DateTime fechaFinal = FechaHasta.Value;
                DateTime fechaInicio = Fecha;

                int totalMeses = (fechaFinal.Year - fechaInicio.Year) * 12 + (fechaFinal.Month - fechaInicio.Month);

                // Contar el mes final si el día de fechaFinal es igual o posterior al día de fechaInicio
                if (fechaFinal.Day >= fechaInicio.Day)
                {
                    totalMeses += 1;
                }

                // Evitar 0 cuotas: como mínimo 1 cuota
                if (totalMeses <= 0)
                {
                    totalMeses = 1;
                }

                return totalMeses;
            }
        }



        /// <summary>
        /// Método para calcular las cuotas pendientes
        /// </summary>
        /// <returns></returns>
        public int CalcularCuotasPendientes()
        {
            DateTime hoy = DateTime.Today;

            // Si no tiene fecha de fin → no hay cuotas “pendientes fijas”
            if (!FechaHasta.HasValue)
            {
                return 0;
            }
                
            DateTime fechaFinal = FechaHasta.Value;
            DateTime fechaInicio = Fecha;

            // El plan terminó
            if (hoy > fechaFinal)
            {
                return 0;
            }

            // Todavía no empezó
            if (hoy < fechaInicio)
            {
                return (fechaFinal.Year - fechaInicio.Year) * 12
                     + (fechaFinal.Month - fechaInicio.Month)
                     + 1;
            }

            // Activo → meses desde hoy hasta fin
            int meses = (fechaFinal.Year - hoy.Year) * 12 + (fechaFinal.Month - hoy.Month);

            // si el día no terminó se suma uno
            if (hoy.Day <= fechaFinal.Day) { meses++; }
                

            return meses;
        }
        // Método ToString 
        public override string ToString()
        {
            return base.ToString() + $" Tipo de pago: Recurrente | Período: desde {Fecha} hasta {FechaHasta} | Pagos pendientes: {CalcularCuotasPendientes()} {Environment.NewLine}";
        }

        public decimal CalcularMontoCuota()
        {
            decimal montoCuota = 0;
            if (CalcularCuotasPendientes() <= 0 && FechaHasta == null)
            {
                return CalcularMontoTotal();
            }
            else if (CalcularCuotasPendientes() > 0)
            {
                montoCuota = CalcularMontoTotal() / CalcularTotalCuotas();
            }
            return montoCuota;
        }
    }
}
