﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidades
{
    public class PagoUnico : Pago
    {

        public int NumRecibo { get; set; }

        // Constructor

        public PagoUnico() { }


        public PagoUnico(MetodoPago metodoPago, decimal monto, TipoGasto tipoGasto, Usuario usuario, string descripcion, DateTime fecha, int numRecibo)
            : base(metodoPago, monto, tipoGasto, usuario, descripcion, fecha)
        {
            NumRecibo = numRecibo;
        }
        // Validaciones
        public void Validar()
        {
            base.Validar();
            if (Fecha > DateTime.Today)
            {
                throw new Exception("La fecha de pago no debe ser futura");
            }
            if (NumRecibo < 0)
            {
                throw new Exception("El número de recibo no puede ser negativo");
            }
            if (NumRecibo == 0)
            {
                throw new Exception("Debe ingresar un número de recibo");
            }
        }
        // Método CalcularMontoTotal (override de clase padre Pago)
        public override decimal CalcularMontoTotal()
        {
            if (MetodoPago == MetodoPago.EFECTIVO)
            {
                return Monto * 0.80m;
            }
            else
            {
                return Monto * 0.90m;
            }
        }

        // Método ToString
        public override string ToString()
        {
            return base.ToString() + $" Tipo de pago: Único | Fecha: {Fecha}  | Recibo: {NumRecibo} {Environment.NewLine}";
        }
    }
}
