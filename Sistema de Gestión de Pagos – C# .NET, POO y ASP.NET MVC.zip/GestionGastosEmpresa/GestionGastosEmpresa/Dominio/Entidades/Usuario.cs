﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidades
{
    public class Usuario : IComparable<Usuario>
    {
        private static int UltimoId { get; set; } = 1;
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Pass { get; set; }
        public string Email { get; set; }
        public Equipo Equipo { get; set; }
        public DateTime FechaIngreso { get; set; }
        public string Rol { get; set; }


        //Constructores
        public Usuario()
        {
            Id = UltimoId++;
        }

        public Usuario(string nombre, string apellido, string pass, Equipo equipo, DateTime fechaIngreso, string rol)
        {
            Id = UltimoId++;
            Nombre = nombre;
            Apellido = apellido;
            Pass = pass;
            Equipo = equipo;
            FechaIngreso = fechaIngreso;
            Rol = rol;
        }
        // Validaciones
        public void Validar()
        {
            if (String.IsNullOrEmpty(Nombre))
            {
                throw new Exception("El nombre no puede estar vacío");
            }
            if (String.IsNullOrEmpty(Apellido))
            {
                throw new Exception("El apellido no puede estar vacío");
            }
            if (Pass.Length < 8)
            {
                throw new Exception("La contraseña debe tener al menos 8 caracteres");
            }
            if (FechaIngreso > DateTime.Now)
            {
                throw new Exception("Debe ingresar una fecha válida");
            }
            if (Equipo is null)
            {
                throw new Exception("El equipo debe ser válido");
            }
        }

        public int CompareTo(Usuario other)
        {
            if (other == null) return 1;


            int resultado = string.Compare(this.Email, other.Email);

            if (resultado > 0)
            {
                return 1;
            }
            else if (resultado < 0)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }


        // Método ToString
        public override string ToString()
        {
            return $"ID: {Id} | Nombre: {Nombre} {Apellido}, Email: {Email}, " +
                   $"Equipo: {Equipo.Nombre}, Ingreso: {FechaIngreso:dd/MM/yyyy}";
        }
    }
}
