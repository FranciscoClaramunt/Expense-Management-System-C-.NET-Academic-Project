﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidades
{
    public class Equipo
    {
        private static int UltimoId { get; set; } = 1;
        public int Id { get; set; }
        public string Nombre { get; set; }

        // Constructores
        public Equipo()
        {
            Id = UltimoId++;
        }

        public Equipo(string nombre)
        {
            Id = UltimoId++;
            Nombre = nombre;
        }
        // Validaciones
        public void Validar()
        {
            if (String.IsNullOrEmpty(Nombre))
            {
                throw new Exception("El nombre no puede estar vacío");
            }
        }

        // Método ToString
        public override string ToString()
        {
            return $"ID: {Id} | Nombre: {Nombre}";
        }
    }
}
