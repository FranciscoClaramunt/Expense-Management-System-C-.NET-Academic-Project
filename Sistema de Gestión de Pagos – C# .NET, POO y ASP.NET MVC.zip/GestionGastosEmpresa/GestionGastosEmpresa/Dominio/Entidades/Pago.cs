﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidades
{
    public abstract class Pago : IComparable<Pago>
    {
        protected static int UltimoId { get; set; } = 1;
        public int Id { get; set; }
        // Enum MetodoPago
        public MetodoPago MetodoPago { get; set; }
        public decimal Monto { get; set; }
        public TipoGasto TipoGasto { get; set; }
        public Usuario Usuario { get; set; }
        public string Descripcion { get; set; }
        public DateTime Fecha { get; set; }

        // Constructor
        public Pago()
        {
            Id = UltimoId++;
        }
        protected Pago(MetodoPago metodoPago, decimal monto, TipoGasto tipoGasto, Usuario usuario, string descripcion, DateTime fecha)
        {
            Id = UltimoId++;
            MetodoPago = metodoPago;
            Monto = monto;
            TipoGasto = tipoGasto;
            Usuario = usuario;
            Descripcion = descripcion;
            Fecha = fecha;
        }
        // Validaciones
        public void Validar()
        {
            if (Monto <= 0)
            {
                throw new Exception("El monto debe ser mayor a 0");
            }
            if (TipoGasto is null)
            {
                throw new Exception("El tipo de gasto debe ser válido");
            }
            if (Usuario is null)
            {
                throw new Exception("El usuario debe ser válido");
            }
            if (String.IsNullOrEmpty(Descripcion))
            {
                throw new Exception("Debe añadir una descripción");
            }
            if (Fecha == default)
            {
                throw new Exception("Debe añadir una fecha de pago válida");
            }
        }
        // Método abstracto CalcularMontoTotal
        public abstract decimal CalcularMontoTotal();

        // Método ToString
        public override string ToString()
        {
            return $"Usuario: {Usuario.Nombre} {Usuario.Apellido}| ID de pago: {Id} | {TipoGasto} | Método de pago: {MetodoPago} | Monto: ${Monto} | Monto total: ${CalcularMontoTotal()} |";
        }


        public int CompareTo(Pago other)
        {
            if (Fecha.Month.CompareTo(other.Fecha.Month) == 0 && Fecha.Year.CompareTo(other.Fecha.Year) == 0)
            {

                if (CalcularMontoTotal().CompareTo(other.CalcularMontoTotal()) > 0)
                {
                    return -1;
                }
                else if (CalcularMontoTotal().CompareTo(other.CalcularMontoTotal()) < 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }


            }
            else
            {
                if (Fecha.CompareTo(other.Fecha) > 0)
                {
                    return -1;
                }
                else if (Fecha.CompareTo(other.Fecha) < 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }

        }

    }

}


