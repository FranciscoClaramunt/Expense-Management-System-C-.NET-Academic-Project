﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Entidades
{
    public class TipoGasto
    {
        private static int UltimoId { get; set; } = 1;
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public bool Eliminado { get; set; }


        // Constructores
        public TipoGasto()
        {
            Id = UltimoId++;
            Eliminado = false;
        }

        public TipoGasto(string nombre, string descripcion)
        {
            Id = UltimoId++;
            Nombre = nombre;
            Descripcion = descripcion;
            Eliminado = false;
        }

        // Validaciones
        public void Validar()
        {
            if (String.IsNullOrEmpty(Nombre))
            {
                throw new Exception("Debe ingresar un nombre");
            }
            if (String.IsNullOrEmpty(Descripcion))
            {
                throw new Exception("Debe añadir una descripción");
            }
        }
        // Método ToString
        public override string ToString()
        {
            return $"Tipo de gasto: {Nombre} | Descripción: {Descripcion}";
        }
    }
}
