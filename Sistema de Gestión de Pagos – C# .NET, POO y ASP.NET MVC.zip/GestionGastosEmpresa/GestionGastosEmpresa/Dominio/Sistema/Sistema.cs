﻿using Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio.Sistema
{
    public class Sistema
    {
        private List<Usuario> _usuarios = new List<Usuario>();
        private List<Equipo> _equipos = new List<Equipo>();
        private List<Pago> _pagos = new List<Pago>();
        private List<TipoGasto> _tipoGastos = new List<TipoGasto>();

        private static Sistema _instance = null;
        private Sistema()
        {
            PrecargarDatos();
        }

        public Usuario ExisteUsuario(string email, string pass)
        {
            foreach (Usuario u in _usuarios)
            {
                if (u.Email.Equals(email) && u.Pass.Equals(pass))
                {
                    return u;
                }
            }
            return null;
        }
        public static Sistema GetInstancia()
        {

            if (_instance == null)
            {
                _instance = new Sistema();
            }

            return _instance;
        }

        // Metodos para obtener las listas guardadas (sin filtros)
        public List<Usuario> GetUsuarios()
        {
            return _usuarios;
        }
        public List<Equipo> GetEquipos()
        {
            return _equipos;
        }
        public List<Pago> GetPagos()
        {
            _pagos.Sort();
            return _pagos;
        }
        public List<TipoGasto> GetTipoGastos()
        {
            return _tipoGastos;
        }
        // Recibe un nombre, si existe un equipo con ese nombre, lo retorna, de lo contrario retorna null
        public Equipo GetEquipoPorNombre(string nom)
        {
            foreach (Equipo e in _equipos)
            {
                if (e.Nombre.ToLower().Equals(nom.ToLower()))
                {
                    return e;
                }
            }
            return null;
        }

        public List<Pago> GetPagosPorEquipo(Equipo equipo)
        {
            List<Pago> resultado = new List<Pago>();
            foreach (Pago p in _pagos)
            {
                if (p.Usuario.Equipo == equipo)
                {
                    resultado.Add(p);
                }
            }
            resultado.Sort();
            return resultado;
        }


        // Recibe un mail, si existe un usuario con ese mail, lo retorna, de lo contrario retorna null
        public Usuario GetUsuarioPorMail(string email)
        {
            foreach (Usuario u in _usuarios)
            {
                if (u.Email.ToLower().Equals(email.ToLower()))
                {
                    return u;
                }
            }
            return null;
        }

        /// <summary>
        /// Devuelve una lista de  pagos que realizó el usuario con ese mail
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public List<Pago> GetPagosPorUsuario(string email)
        {
            List<Pago> resultado = new List<Pago>();

            if (String.IsNullOrEmpty(email))
            {
                throw new Exception("El email no puede estar vacío");
            }

            if (GetUsuarioPorMail(email) == null)
            {
                throw new Exception("No existe un usuario con el mail ingresado");
            }

            foreach (Pago p in _pagos)
            {
                if (p.Usuario.Email.Equals(email))
                {
                    resultado.Add(p);
                }
            }

            if (resultado.Count == 0)
            {
                throw new Exception("El usuario ingresado no tiene pagos realizados");
            }

            resultado.Sort();
            return resultado;
        }
        /// <summary>
        /// Devuelve una lista de usuarios que pertenecen al equipo con ese nombre
        /// </summary>
        /// <param name="equipo"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public List<Usuario> GetUsuariosPorEquipo(string equipo)
        {
            List<Usuario> resultado = new List<Usuario>();

            if (String.IsNullOrEmpty(equipo))
            {
                throw new Exception("El nombre del equipo no puede estar vacío");
            }

            if (GetEquipoPorNombre(equipo) == null)
            {
                throw new Exception("El nombre del equipo ingresado no existe");
            }

            foreach (Usuario u in _usuarios)
            {
                if (u.Equipo.Nombre.ToLower().Equals(equipo.ToLower()))
                {
                    resultado.Add(u);
                }
            }
            resultado.Sort();
            return resultado;
        }

        /// <summary>
        /// Devuelve una lista de pagos correspondiente al mes actual (NO UTILIZADO PARA ESTA PRIMERA ENTREGA)
        /// </summary>
        /// <returns></returns>
        public List<Pago> GetPagosMesActual(List<Pago> listaDePagos)
        {
            List<Pago> resultado = new List<Pago>();

            foreach (Pago p in listaDePagos)
            {
                // Si el pago se realizo en ese mes, se agrega a la lista
                if (p.Fecha.Month.Equals(DateTime.Now.Month) && p.Fecha.Year.Equals(DateTime.Now.Year))
                {
                    resultado.Add(p);
                }
            }
            resultado.Sort();
            return resultado;
        }

        public List<Pago> GetPagosPorMes(int anio, int mes)
        {

            List<Pago> resultado = new List<Pago>();

            foreach (Pago p in _pagos)
            {
                if (p.Fecha.Year == anio && p.Fecha.Month == mes)
                {
                    resultado.Add(p);
                }
            }
            resultado.Sort();
            return resultado;
        }

        /// <summary>
        /// GetEquipoPorId - recibe un id y busca en el listado de equipos el equipo correspondiente
        /// </summary>
        /// <param name="idEquipo"></param>
        /// <returns></returns>
        public Equipo GetEquipoPorId(int idEquipo)
        {
            foreach (Equipo e in _equipos)
            {
                if (e.Id.Equals(idEquipo))
                {
                    // Retorna el equipo una vez lo encuentra
                    return e;
                }
            }
            // Si no se encuentra el equipo, retorna null
            return null;
        }
        // Métodos de alta
        public void AltaUsuario(Usuario x)
        {
            x.Validar();

            x.Email = GenerarEmail(x.Nombre, x.Apellido);
            _usuarios.Add(x);
        }
        public void AltaEquipo(Equipo x)
        {
            x.Validar();
            _equipos.Add(x);
        }
        public void AltaPago(Pago x)
        {
            x.Validar();
            _pagos.Add(x);
        }

        public void AltaPagoRecurrente(PagoRecurrente x)
        {
            x.Validar();
            _pagos.Add(x);
        }

        public void AltaPagoUnico(PagoUnico x)
        {
            if (ExisteRecibo(x.NumRecibo))
            {
                throw new Exception("El número de recibo ya existe. No se puede repetir.");
            }
            x.Validar();
            _pagos.Add(x);
        }

        public void AltaTipoGasto(TipoGasto x)
        {
            x.Validar();
            _tipoGastos.Add(x);
        }

        /// <summary>
        /// Metodo que indica si existe un usuario con ese mail
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        private bool ExisteEmail(string email)
        {
            bool existe = false;
            foreach (Usuario u in _usuarios)
            {
                if (u.Email.Equals(email))
                {
                    existe = true;
                    break;
                }
            }
            return existe;
        }

        private bool ExisteRecibo (int numRecibo)
        {
            bool existe = false;
            foreach (Pago pago in _pagos)
            {
                if (pago is PagoUnico pu && pu.NumRecibo.Equals(numRecibo))
                {
                    existe = true;
                    break;
                }
            }
            return existe;
        }

        /// <summary>
        /// Método para generar automáticamente un correo
        /// </summary>
        /// <param name="nom"></param>
        /// <param name="ape"></param>
        /// <returns></returns>
        public string GenerarEmail(string nom, string ape)
        {
            // Variable que contendrá la parte del usuario del correo
            string usuario;
            // Dominio fijo de la empresa
            string dominio = "@laEmpresa.com";
            // Si el nombre o el apellido tienen menos de 3 caracteres, se usan completos
            if (nom.Length < 3 || ape.Length < 3)
            {
                usuario = nom.ToLower() + ape.ToLower();
            }
            else
            {
                // Si ambos tienen 3 o más caracteres, se toman las tres primeras letras de cada uno
                string tresPrimerasNom = nom.Substring(0, 3);
                string tresPrimerasApe = ape.Substring(0, 3);
                usuario = tresPrimerasNom.ToLower() + tresPrimerasApe.ToLower();
            }
            // Si ya existe un usuario con el mismo correo, se agrega un número aleatorio para evitar duplicados
            if (ExisteEmail(usuario + dominio))
            {
                int numRandom = new Random().Next(1000, 9999);
                usuario += numRandom.ToString();
            }
            // Se construye el correo final concatenando el usuario con el dominio
            string email = usuario + dominio;
            return email;
        }

        public TipoGasto GetTipoGastoPorId(int idTipoGasto)
        {
            foreach (TipoGasto tg in _tipoGastos)
            {
                if (tg.Id.Equals(idTipoGasto))
                {
                    return tg;
                }
            }
            return null;
        }

        public void EliminarTipoGasto(int id)
        {
            foreach (TipoGasto tg in _tipoGastos)
            {
                if (tg.Id.Equals(id))
                {
                    tg.Eliminado = true;
                }
            }
        }

        // Método para la precarga de datos
        private void PrecargarDatos()
        {
            // =========================
            // EQUIPOS
            // =========================

            Equipo equipo1 = new Equipo("Marketing");
            Equipo equipo2 = new Equipo("Finanzas");
            Equipo equipo3 = new Equipo("Ventas");
            Equipo equipo4 = new Equipo("Desarrollo");

            AltaEquipo(equipo1);
            AltaEquipo(equipo2);
            AltaEquipo(equipo3);
            AltaEquipo(equipo4);

            // =========================
            // USUARIOS
            // =========================

            Usuario usuario1 = new Usuario("Alvaro", "Gomez", "Clave1234", equipo1, new DateTime(2025, 03, 04), "Gerente");
            Usuario usuario2 = new Usuario("Lucia", "Martinez", "Pass8901", equipo1, new DateTime(2024, 07, 12), "Empleado");
            Usuario usuario3 = new Usuario("Javier", "Ramirez", "Segura2023", equipo1, new DateTime(2023, 11, 25), "Empleado");
            Usuario usuario4 = new Usuario("Carmen", "Lopez", "Marcas456", equipo1, new DateTime(2025, 01, 19), "Empleado");
            Usuario usuario5 = new Usuario("Miguel", "Paredes", "Mix2025go", equipo1, new DateTime(2023, 06, 30), "Empleado");
            Usuario usuario6 = new Usuario("Elena", "Torres", "Clave9912", equipo2, new DateTime(2024, 09, 05), "Gerente");
            Usuario usuario7 = new Usuario("Pablo", "Vega", "Num7823x", equipo2, new DateTime(2023, 12, 08), "Empleado");
            Usuario usuario8 = new Usuario("Silvia", "Moreno", "Safe1459", equipo2, new DateTime(2025, 04, 21), "Empleado");
            Usuario usuario9 = new Usuario("Raul", "Gutierrez", "Pass4321", equipo2, new DateTime(2024, 02, 16), "Empleado");
            Usuario usuario10 = new Usuario("Nuria", "Herrera", "Mix9845z", equipo2, new DateTime(2023, 10, 09), "Empleado");
            Usuario usuario11 = new Usuario("Sergio", "Cruz", "Clave7012", equipo3, new DateTime(2024, 08, 14), "Gerente");
            Usuario usuario12 = new Usuario("Laura", "Reyes", "PassA123", equipo3, new DateTime(2025, 02, 03), "Empleado");
            Usuario usuario13 = new Usuario("Andres", "Navarro", "Seguro777", equipo3, new DateTime(2023, 09, 27), "Empleado");
            Usuario usuario14 = new Usuario("Rosa", "Campos", "Clave5544", equipo3, new DateTime(2024, 05, 30), "Empleado");
            Usuario usuario15 = new Usuario("Hector", "Jimenez", "Code9900", equipo3, new DateTime(2025, 07, 18), "Empleado");
            Usuario usuario16 = new Usuario("Valeria", "Suarez", "Mix1239a", equipo4, new DateTime(2023, 04, 11), "Gerente");
            Usuario usuario17 = new Usuario("Diego", "Luna", "Dev89000", equipo4, new DateTime(2024, 01, 28), "Empleado");
            Usuario usuario18 = new Usuario("Marta", "Castillo", "Soft7711", equipo4, new DateTime(2025, 06, 09), "Empleado");
            Usuario usuario19 = new Usuario("Julian", "Ortega", "Pass6678", equipo4, new DateTime(2023, 08, 15), "Empleado");
            Usuario usuario20 = new Usuario("Adriana", "Santos", "Clave9812", equipo4, new DateTime(2024, 11, 20), "Empleado");
            Usuario usuario21 = new Usuario("Fernando", "Rivas", "Code2025", equipo1, new DateTime(2023, 07, 03), "Empleado");
            Usuario usuario22 = new Usuario("Patricia", "Navas", "Mix2024x", equipo2, new DateTime(2025, 09, 29), "Empleado");

            AltaUsuario(usuario1); AltaUsuario(usuario2); AltaUsuario(usuario3); AltaUsuario(usuario4); AltaUsuario(usuario5);
            AltaUsuario(usuario6); AltaUsuario(usuario7); AltaUsuario(usuario8); AltaUsuario(usuario9); AltaUsuario(usuario10); AltaUsuario(usuario11);
            AltaUsuario(usuario12); AltaUsuario(usuario13); AltaUsuario(usuario14); AltaUsuario(usuario15); AltaUsuario(usuario16);
            AltaUsuario(usuario17); AltaUsuario(usuario18); AltaUsuario(usuario19); AltaUsuario(usuario20); AltaUsuario(usuario21); AltaUsuario(usuario22);

            // =========================
            // TIPOS DE GASTO
            // =========================

            TipoGasto tipo1 = new TipoGasto("Transporte", "Gastos relacionados con movilidad y transporte.");
            TipoGasto tipo2 = new TipoGasto("Comidas", "Gastos por alimentación durante viajes o reuniones.");
            TipoGasto tipo3 = new TipoGasto("Alojamiento", "Costos de hospedaje en viajes laborales.");
            TipoGasto tipo4 = new TipoGasto("Material de Oficina", "Artículos y suministros para el trabajo diario.");
            TipoGasto tipo5 = new TipoGasto("Software", "Licencias o suscripciones de herramientas digitales.");
            TipoGasto tipo6 = new TipoGasto("Eventos", "Costos de asistencia o participación en eventos empresariales.");
            TipoGasto tipo7 = new TipoGasto("Formación", "Cursos, talleres o capacitaciones profesionales.");
            TipoGasto tipo8 = new TipoGasto("Publicidad", "Inversión en campañas y materiales de promoción.");
            TipoGasto tipo9 = new TipoGasto("Telefonía", "Gastos de comunicación móvil y servicios relacionados.");
            TipoGasto tipo10 = new TipoGasto("Otros", "Gastos no categorizados en los tipos anteriores.");

            AltaTipoGasto(tipo1); AltaTipoGasto(tipo2); AltaTipoGasto(tipo3); AltaTipoGasto(tipo4); AltaTipoGasto(tipo5);
            AltaTipoGasto(tipo6); AltaTipoGasto(tipo7); AltaTipoGasto(tipo8); AltaTipoGasto(tipo9); AltaTipoGasto(tipo10);

            // =========================
            // PAGOS RECURRENTES
            // =========================

            PagoRecurrente pagoR1 = new PagoRecurrente(MetodoPago.CREDITO, 1200, tipo5, usuario3, "Suscripción Adobe", new DateTime(2023, 01, 10), new DateTime(2023, 12, 10));
            PagoRecurrente pagoR2 = new PagoRecurrente(MetodoPago.DEBITO, 950, tipo7, usuario5, "Curso liderazgo", new DateTime(2024, 03, 15), new DateTime(2024, 09, 15));
            PagoRecurrente pagoR3 = new PagoRecurrente(MetodoPago.EFECTIVO, 300, tipo1, usuario7, "Tarjeta de transporte", new DateTime(2023, 05, 01), new DateTime(2025, 05, 01));
            PagoRecurrente pagoR4 = new PagoRecurrente(MetodoPago.CREDITO, 1400, tipo5, usuario2, "Licencia Office 365", new DateTime(2023, 06, 01), new DateTime(2024, 06, 01));
            PagoRecurrente pagoR5 = new PagoRecurrente(MetodoPago.DEBITO, 700, tipo4, usuario8, "Compra mensual papelería", new DateTime(2024, 01, 01), new DateTime(2024, 12, 01));
            PagoRecurrente pagoR6 = new PagoRecurrente(MetodoPago.CREDITO, 2500, tipo10, usuario10, "Plan gimnasio premium", new DateTime(2024, 10, 01), null);
            PagoRecurrente pagoR7 = new PagoRecurrente(MetodoPago.DEBITO, 420, tipo2, usuario4, "Servicio de música", new DateTime(2024, 02, 10), new DateTime(2026, 02, 10));
            PagoRecurrente pagoR8 = new PagoRecurrente(MetodoPago.EFECTIVO, 1500, tipo7, usuario1, "Clases de inglés", new DateTime(2024, 09, 01), new DateTime(2025, 12, 01));
            PagoRecurrente pagoR9 = new PagoRecurrente(MetodoPago.CREDITO, 950, tipo5, usuario6, "Suscripción Canva Pro", new DateTime(2024, 07, 15), null);
            PagoRecurrente pagoR10 = new PagoRecurrente(MetodoPago.DEBITO, 2200, tipo10, usuario9, "Alquiler co-working", new DateTime(2024, 06, 01), new DateTime(2025, 12, 01));
            PagoRecurrente pagoR11 = new PagoRecurrente(MetodoPago.CREDITO, 1800, tipo8, usuario12, "Seguro de salud", new DateTime(2023, 10, 01), new DateTime(2026, 10, 01));
            PagoRecurrente pagoR12 = new PagoRecurrente(MetodoPago.EFECTIVO, 300, tipo1, usuario15, "Tarjeta transporte mensual", new DateTime(2024, 05, 01), new DateTime(2025, 12, 01));
            PagoRecurrente pagoR13 = new PagoRecurrente(MetodoPago.CREDITO, 1250, tipo5, usuario13, "Suscripción Netflix", new DateTime(2023, 11, 01), new DateTime(2026, 11, 01));
            PagoRecurrente pagoR14 = new PagoRecurrente(MetodoPago.DEBITO, 850, tipo2, usuario18, "Clases de yoga", new DateTime(2024, 04, 15), new DateTime(2026, 04, 15));
            PagoRecurrente pagoR15 = new PagoRecurrente(MetodoPago.CREDITO, 600, tipo4, usuario14, "Mantenimiento hosting web", new DateTime(2024, 02, 01), new DateTime(2026, 02, 01));
            PagoRecurrente pagoR16 = new PagoRecurrente(MetodoPago.DEBITO, 2750, tipo7, usuario16, "Plan nutricionista", new DateTime(2024, 09, 20), new DateTime(2026, 09, 20));
            PagoRecurrente pagoR17 = new PagoRecurrente(MetodoPago.CREDITO, 480, tipo2, usuario20, "Suscripción Spotify", new DateTime(2024, 01, 10), new DateTime(2026, 01, 10));
            PagoRecurrente pagoR18 = new PagoRecurrente(MetodoPago.EFECTIVO, 3200, tipo10, usuario19, "Clases de música", new DateTime(2023, 12, 01), new DateTime(2026, 12, 01));
            PagoRecurrente pagoR19 = new PagoRecurrente(MetodoPago.CREDITO, 1950, tipo10, usuario17, "Alquiler depósito", new DateTime(2024, 03, 01), null);
            PagoRecurrente pagoR20 = new PagoRecurrente(MetodoPago.DEBITO, 2100, tipo7, usuario21, "Cursos de Data Science", new DateTime(2024, 05, 01), new DateTime(2025, 11, 01));
            PagoRecurrente pagoR21 = new PagoRecurrente(MetodoPago.EFECTIVO, 900, tipo8, usuario22, "Seguro bicicleta", new DateTime(2024, 06, 15), new DateTime(2025, 12, 15));
            PagoRecurrente pagoR22 = new PagoRecurrente(MetodoPago.CREDITO, 1450, tipo5, usuario11, "Suscripción Apple One", new DateTime(2023, 08, 01), new DateTime(2025, 08, 01));
            PagoRecurrente pagoR23 = new PagoRecurrente(MetodoPago.DEBITO, 2800, tipo8, usuario2, "Gimnasio familiar", new DateTime(2024, 10, 01), new DateTime(2026, 10, 01));
            PagoRecurrente pagoR24 = new PagoRecurrente(MetodoPago.CREDITO, 3700, tipo9, usuario5, "Curso avanzado de programación", new DateTime(2024, 07, 01), new DateTime(2025, 12, 01));
            PagoRecurrente pagoR25 = new PagoRecurrente(MetodoPago.EFECTIVO, 450, tipo1, usuario8, "Recarga transporte", new DateTime(2023, 03, 01), new DateTime(2026, 03, 01));

            AltaPago(pagoR1); AltaPago(pagoR2); AltaPago(pagoR3); AltaPago(pagoR4); AltaPago(pagoR5); AltaPago(pagoR6); AltaPago(pagoR7);
            AltaPago(pagoR8); AltaPago(pagoR9); AltaPago(pagoR10); AltaPago(pagoR11); AltaPago(pagoR12); AltaPago(pagoR13); AltaPago(pagoR14);
            AltaPago(pagoR15); AltaPago(pagoR16); AltaPago(pagoR17); AltaPago(pagoR18); AltaPago(pagoR19); AltaPago(pagoR20); AltaPago(pagoR21);
            AltaPago(pagoR22); AltaPago(pagoR23); AltaPago(pagoR24); AltaPago(pagoR25);


            // =========================
            // PAGOS ÚNICOS
            // =========================

            PagoUnico pagoU1 = new PagoUnico(MetodoPago.EFECTIVO, 850, tipo2, usuario7, "Almuerzo con cliente", new DateTime(2024, 06, 12), 1001);
            PagoUnico pagoU2 = new PagoUnico(MetodoPago.CREDITO, 1500, tipo3, usuario14, "Hotel en viaje de negocios", new DateTime(2025, 03, 20), 1002);
            PagoUnico pagoU3 = new PagoUnico(MetodoPago.DEBITO, 120, tipo4, usuario6, "Compra de carpetas", new DateTime(2023, 09, 10), 1003);
            PagoUnico pagoU4 = new PagoUnico(MetodoPago.EFECTIVO, 75, tipo9, usuario12, "Regalo de cumpleaños corporativo", new DateTime(2024, 11, 22), 1004);
            PagoUnico pagoU5 = new PagoUnico(MetodoPago.CREDITO, 2000, tipo8, usuario19, "Campaña publicitaria", new DateTime(2023, 04, 02), 1005);
            PagoUnico pagoU6 = new PagoUnico(MetodoPago.DEBITO, 650, tipo1, usuario2, "Compra de insumos de limpieza", new DateTime(2024, 05, 10), 1006);
            PagoUnico pagoU7 = new PagoUnico(MetodoPago.CREDITO, 2800, tipo10, usuario5, "Mantenimiento de servidores", new DateTime(2025, 02, 15), 1007);
            PagoUnico pagoU8 = new PagoUnico(MetodoPago.EFECTIVO, 430, tipo6, usuario9, "Taxi al aeropuerto", new DateTime(2023, 08, 21), 1008);
            PagoUnico pagoU9 = new PagoUnico(MetodoPago.CREDITO, 1900, tipo8, usuario3, "Compra de software contable", new DateTime(2024, 09, 05), 1009);
            PagoUnico pagoU10 = new PagoUnico(MetodoPago.DEBITO, 1200, tipo9, usuario4, "Reparación de equipo", new DateTime(2025, 01, 19), 1010);
            PagoUnico pagoU11 = new PagoUnico(MetodoPago.EFECTIVO, 350, tipo4, usuario6, "Material de oficina", new DateTime(2024, 11, 11), 1011);
            PagoUnico pagoU12 = new PagoUnico(MetodoPago.CREDITO, 2500, tipo6, usuario8, "Evento corporativo", new DateTime(2024, 12, 20), 1012);
            PagoUnico pagoU13 = new PagoUnico(MetodoPago.DEBITO, 950, tipo2, usuario10, "Cena con proveedores", new DateTime(2023, 10, 08), 1013);
            PagoUnico pagoU14 = new PagoUnico(MetodoPago.CREDITO, 1450, tipo5, usuario11, "Renovación dominio web", new DateTime(2024, 03, 03), 1014);
            PagoUnico pagoU15 = new PagoUnico(MetodoPago.EFECTIVO, 220, tipo9, usuario13, "Pago mensajería urgente", new DateTime(2024, 08, 28), 1015);
            PagoUnico pagoU16 = new PagoUnico(MetodoPago.CREDITO, 3100, tipo10, usuario15, "Compra de mobiliario", new DateTime(2023, 12, 10), 1016);
            PagoUnico pagoU17 = new PagoUnico(MetodoPago.DEBITO, 580, tipo4, usuario17, "Papelería general", new DateTime(2025, 04, 07), 1017);
            PagoUnico pagoU18 = new PagoUnico(MetodoPago.EFECTIVO, 1750, tipo8, usuario18, "Viaje a reunión regional", new DateTime(2024, 07, 15), 1018);
            PagoUnico pagoU19 = new PagoUnico(MetodoPago.CREDITO, 2600, tipo9, usuario20, "Publicidad digital", new DateTime(2024, 09, 22), 1019);
            PagoUnico pagoU20 = new PagoUnico(MetodoPago.DEBITO, 870, tipo6, usuario21, "Compra de toner impresora", new DateTime(2024, 02, 17), 1020);
            PagoUnico pagoU21 = new PagoUnico(MetodoPago.EFECTIVO, 120, tipo1, usuario16, "Café reunión de equipo", new DateTime(2025, 05, 02), 1021);
            PagoUnico pagoU22 = new PagoUnico(MetodoPago.CREDITO, 4100, tipo7, usuario22, "Actualización hardware oficina", new DateTime(2024, 10, 14), 1022);

            AltaPago(pagoU1); AltaPago(pagoU2); AltaPago(pagoU3); AltaPago(pagoU4); AltaPago(pagoU5); AltaPago(pagoU6); AltaPago(pagoU7); AltaPago(pagoU8);
            AltaPago(pagoU9); AltaPago(pagoU10); AltaPago(pagoU11); AltaPago(pagoU12); AltaPago(pagoU13); AltaPago(pagoU14); AltaPago(pagoU15);
            AltaPago(pagoU16); AltaPago(pagoU17); AltaPago(pagoU18); AltaPago(pagoU19); AltaPago(pagoU20); AltaPago(pagoU21); AltaPago(pagoU22);

        }
        // Falta implementar
        public decimal GetGastadoEsteMes(int? lid)
        {
            decimal totalGastado = 0;
            int mesActual = DateTime.Now.Month;
            int anioActual = DateTime.Now.Year;
            List<Pago> pagosDelMes = GetPagosPorMes(anioActual, mesActual);

            foreach (Pago p in pagosDelMes)
            {
                if (p.Usuario.Id == lid)
                {
                    if (p is PagoRecurrente pr)
                        totalGastado += pr.CalcularMontoCuota();
                    else
                    {
                        totalGastado += p.CalcularMontoTotal();
                    }
                }
            }
            return totalGastado;
        }

        public Usuario GetUsuarioPorId(int? lid)
        {
            foreach (Usuario u in _usuarios)
            {
                if (u.Id.Equals(lid))
                {
                    // Retorna el equipo una vez lo encuentra
                    return u;
                }
            }
            // Si no se encuentra el equipo, retorna null
            return null;
        }
    }
}

